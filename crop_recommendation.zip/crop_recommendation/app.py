## Importing necessary libraries for the web app
import streamlit as st
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
import pickle
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from PIL import Image  # ✅ FIX: Import Image from PIL

# ✅ FIX: Correct image loading
image_path = "crop.png"

if os.path.exists(image_path):
    img = Image.open(image_path)
    st.image(img, caption="Crop Recommendation", use_column_width=True)
else:
    st.warning("⚠️ Image not found! Please check the file path.")

# ✅ FIX: Ensure dataset file exists
dataset_path = "Crop_recommendation.csv"

if os.path.exists(dataset_path):
    df = pd.read_csv(dataset_path)
else:
    st.error("⚠️ Dataset file not found! Please check the file path.")

# Features & labels
X = df[['N', 'P', 'K', 'temperature', 'humidity', 'ph', 'rainfall']]
y = df['label']

# Train-test split
Xtrain, Xtest, Ytrain, Ytest = train_test_split(X, y, test_size=0.3, random_state=42)

# Train model
RF = RandomForestClassifier(n_estimators=20, random_state=5)
RF.fit(Xtrain, Ytrain)

# ✅ FIX: Save trained model
RF_pkl_filename = 'RF.pkl'
with open(RF_pkl_filename, 'wb') as model_file:
    pickle.dump(RF, model_file)

# ✅ FIX: Load trained model
with open(RF_pkl_filename, 'rb') as model_file:
    RF_Model_pkl = pickle.load(model_file)

## Function to make predictions
def predict_crop(nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall):
    prediction = RF_Model_pkl.predict(np.array([nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall]).reshape(1, -1))
    return prediction[0]

## Streamlit UI
def main():
    st.markdown("<h1 style='text-align: center;'>🌿 SMART CROP RECOMMENDATION 🌱</h1>", unsafe_allow_html=True)
    
    st.sidebar.title("🌾 PlantOra - Crop Predictor")
    st.sidebar.header("Enter Crop Details")
    
    # ✅ FIX: Ensure valid input ranges
    nitrogen = st.sidebar.slider("Nitrogen", 0, 140, 50)
    phosphorus = st.sidebar.slider("Phosphorus", 0, 145, 50)
    potassium = st.sidebar.slider("Potassium", 0, 205, 50)
    temperature = st.sidebar.slider("Temperature (°C)", 0, 51, 25)
    humidity = st.sidebar.slider("Humidity (%)", 0, 100, 50)
    ph = st.sidebar.slider("pH Level", 0.0, 14.0, 7.0)
    rainfall = st.sidebar.slider("Rainfall (mm)", 0, 500, 200)

    if st.sidebar.button("Predict"):
        prediction = predict_crop(nitrogen, phosphorus, potassium, temperature, humidity, ph, rainfall)
        st.success(f"✅ Recommended Crop: **{prediction}**")

if __name__ == '__main__':
    main()
